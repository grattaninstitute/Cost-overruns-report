#' @title Historical dataset
#' @description Each project in the project_dataset (constructed from the Investment Monitor) has a set of exit information (final cost, whether it was completed or deleted, etc.). This data is contained in this spreadsheet.
#' 
"historical_dataset"