#' @title completed_project_list
#' @description List of the transport projects in project_dataset (infrastructure projects considered for investment between 2000-2015, and captured by the Investment Monitor). The key feature of this dataset is that it includes series Private_project_Grattan and Public_project_Grattan, which is data on the ownership of infrastructure projects that has been manually collected.  Data has been drawn from: Projects by mode and ownership - Project List_LD.xlsx.
#' 
"completed_project_list"

