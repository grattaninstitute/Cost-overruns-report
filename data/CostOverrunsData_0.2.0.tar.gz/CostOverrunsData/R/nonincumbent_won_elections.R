#' @title nonincumbent_won_elections
#' @description List of the dates and jurisdictions of Australian state and federal elections, 2000-2015, that were not won by the incumbent.
#' 
"nonincumbent_won_elections"