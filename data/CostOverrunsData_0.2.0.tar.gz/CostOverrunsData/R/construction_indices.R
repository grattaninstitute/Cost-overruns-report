#' @title construction_indices
#' @description 6427.0 Producer Price Indexes, Australia. Table 17. Output of the Construction industries, subdivision and class index numbers. Series ID: A2333649T. Description: Quarterly price index for the Australian building construction industry, Sept 1996 - Mar 2016.
#' 
"construction_indices"