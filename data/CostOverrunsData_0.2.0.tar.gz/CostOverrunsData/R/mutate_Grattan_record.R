#' Construct Grattan record
#'
#' @param .data A dataset with variables \code{`Record No`} and \code{`Project No.`}
#' @return The dataset with an extra variable, \code{Grattan_record}.
#' @export

mutate_Grattan_record <- function(.data){
  stopifnot(is.data.frame(.data),
            "Record No" %in% names(.data),
            "Project No." %in% names(.data))

  `Record No` <- `Project No.` <- NULL
  dplyr::mutate(.data,
                Grattan_record = dplyr::if_else(is.na(`Record No`),
                                                `Project No.`,
                                                `Record No`))

}
