#' @title incumbent_won_elections
#' @description List of the dates and jurisdictions of Australian state and federal elections, 2000-2015, that were won by the incumbent.
#' 
"incumbent_won_elections"