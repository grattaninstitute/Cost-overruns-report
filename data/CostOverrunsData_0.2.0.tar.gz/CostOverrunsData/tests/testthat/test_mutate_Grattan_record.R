context("Grattan record")



test_that("Grattan record works with known variables", {
  dat <- data_frame(`Project No.` = c(1, 2, 3), `Record No` = c(1, 2, NA))

  expect_identical(mutate_Grattan_record(data_frame(`Project No.` = c(1, 2, 3), `Record No` = c(1, 2, NA))),
                   data_frame(`Project No.` = c(1, 2, 3), `Record No` = c(1, 2, NA), Grattan_record = c(1, 2, 3)))
})
